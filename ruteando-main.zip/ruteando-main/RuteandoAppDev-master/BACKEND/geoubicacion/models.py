from django.db import models
from comun.models import BaseModel
from django.http import JsonResponse, HttpResponseNotAllowed

class APIGeocodingCache(BaseModel):
    latitud = models.DecimalField(max_digits=10, decimal_places=7)
    longitud = models.DecimalField(max_digits=10, decimal_places=7)
    proveedor = models.CharField(max_length=100, default='google')
    hash_geoloc = models.CharField(max_length=100, db_index=True)
    raw_response = models.JSONField()

    def __str__(self):
        return f"{self.proveedor}:{self.hash_geoloc} ({self.latitud}, {self.longitud})"


class Direccion(BaseModel):
    geocoding_cache = models.ForeignKey(
        APIGeocodingCache, on_delete=models.SET_NULL, null=True, blank=True, related_name="direcciones"
    )
    calle = models.CharField(max_length=100)
    numero = models.CharField(max_length=50)
    piso = models.CharField(max_length=20, null=True, blank=True)
    depto = models.CharField(max_length=20, null=True, blank=True)
    ciudad = models.CharField(max_length=100)
    provincia = models.CharField(max_length=100)
    pais = models.CharField(max_length=100)
    codigo_postal = models.CharField(max_length=20, null=True, blank=True)
    hash_direccion = models.CharField(max_length=100, unique=True, db_index=True)
    texto_normalizado = models.TextField()

    def __str__(self):
        return f"{self.calle} {self.numero}, {self.ciudad}"


def eliminar_direccion(request, id):
    """
    Elimina una dirección del modelo Direccion por ID.
    Endpoint: DELETE /api/direcciones/<id>/
    """
    if request.method != 'DELETE':
        return HttpResponseNotAllowed(['DELETE'])

    try:
        direccion = Direccion.objects.get(id=id)

        # 🧹 Si querés limpiar el cache de geocoding no usado:
        geocache = direccion.geocoding_cache
        direccion.delete()

        # Si la cache no tiene más direcciones relacionadas, también la borramos
        if geocache and geocache.direcciones.count() == 0:
            geocache.delete()

        return JsonResponse({'mensaje': 'Dirección eliminada correctamente'})
    except Direccion.DoesNotExist:
        return JsonResponse({'error': 'Dirección no encontrada'}, status=404)