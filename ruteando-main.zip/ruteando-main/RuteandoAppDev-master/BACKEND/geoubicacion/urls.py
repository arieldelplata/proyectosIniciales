from django.urls import path
from .views import CargarDireccionesView, EliminarDireccionView

urlpatterns = [
    path('cargar_direcciones/', CargarDireccionesView.as_view(), name='cargar_direcciones'),
    path('<int:id>/', EliminarDireccionView.as_view(), name='eliminar_direccion'),
]
