import hashlib
import re
import requests
from django.conf import settings


def parsear_calle_y_numero(formatted_address):
    """Fallback simple para extraer calle (multi-palabra) y número desde formatted_address."""
    if not formatted_address:
        return "", ""
    try:
        primera_parte = (formatted_address.split(",", 1)[0] or "").strip()
        m = re.match(r"^(.*?)[\s,]+(\d+[A-Za-z0-9\-\/]*?)$", primera_parte)
        if m:
            return m.group(1).strip(), m.group(2).strip()
        return primera_parte, ""
    except Exception:
        return "", ""


def generar_hash_direccion(address_data):
    # Hash único por dirección exacta (incluye piso/depto)
    comps = address_data.get("components", {})
    formatted = address_data.get("formatted_address")
    route = comps.get("route") or ""
    street_number = comps.get("street_number") or ""
    if not route or not street_number:
        calle_fbk, numero_fbk = parsear_calle_y_numero(formatted)
        route = route or calle_fbk
        street_number = street_number or numero_fbk
    locality = comps.get("locality", "")
    admin1 = comps.get("administrative_area_level_1", "")
    country = comps.get("country", "")
    floor = address_data.get("floor", "")
    apartment = address_data.get("apartment", "")

    base_str = f"{route} {street_number}, {locality}, {admin1}, {country}, {floor}, {apartment}"
    return hashlib.sha256(base_str.strip().lower().encode()).hexdigest()


def generar_hash_geoloc(address_data):
    # Hash de geolocalización (sin piso/depto) del lugar físico
    comps = address_data.get("components", {})
    formatted = address_data.get("formatted_address")
    route = comps.get("route") or ""
    street_number = comps.get("street_number") or ""
    if not route or not street_number:
        calle_fbk, numero_fbk = parsear_calle_y_numero(formatted)
        route = route or calle_fbk
        street_number = street_number or numero_fbk
    locality = comps.get("locality", "")
    admin1 = comps.get("administrative_area_level_1", "")
    country = comps.get("country", "")

    base_str = f"{route} {street_number}, {locality}, {admin1}, {country}"
    return hashlib.sha256(base_str.strip().lower().encode()).hexdigest()


def _get_component_from_google(address_components, key):
    for comp in address_components or []:
        if key in (comp.get("types") or []):
            return comp.get("long_name")
    return None


def extraer_componentes_google(raw_geocode_response):
    """Extrae route/street_number/etc. desde la respuesta cruda de Google Geocoding."""
    if not raw_geocode_response:
        return {}
    try:
        results = raw_geocode_response.get("results") or []
        if not results:
            return {}
        first = results[0]
        comps = first.get("address_components", [])
        return {
            "route": _get_component_from_google(comps, "route") or "",
            "street_number": _get_component_from_google(comps, "street_number") or "",
            "locality": _get_component_from_google(comps, "locality") or "",
            "administrative_area_level_1": _get_component_from_google(comps, "administrative_area_level_1") or "",
            "country": _get_component_from_google(comps, "country") or "",
            "postal_code": _get_component_from_google(comps, "postal_code") or "",
            "formatted_address": first.get("formatted_address", ""),
        }
    except Exception:
        return {}


def obtener_coordenadas_google(formatted_address):
    # Llama a la API de Google Geocoding si no existe en cache.
    api_key = settings.GOOGLE_MAPS_API_KEY
    url = f"https://maps.googleapis.com/maps/api/geocode/json"
    params = {"address": formatted_address, "key": api_key}

    resp = requests.get(url, params=params)
    data = resp.json()

    if data["status"] != "OK" or not data["results"]:
        return None

    loc = data["results"][0]["geometry"]["location"]
    return loc["lat"], loc["lng"], data

