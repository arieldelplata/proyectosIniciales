from functools import wraps
from rest_framework.response import Response
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.request import Request


def solo_gestores(view_func):
    @wraps(view_func)
    def wrapper(*args, **kwargs):
        # En métodos de clase de APIView: args[0] = self, args[1] = request
        # Necesitamos extraer el request correctamente
        request = None
        
        # Si hay 2 o más argumentos, y el primero es una instancia de APIView
        # entonces el segundo debe ser el request
        if len(args) >= 2:
            first_arg = args[0]
            second_arg = args[1] if len(args) > 1 else None
            
            # Verificar si el primer argumento es una instancia de APIView
            if isinstance(first_arg, APIView):
                # Es un método de clase, el request es el segundo argumento
                request = second_arg
            elif hasattr(first_arg, 'user') and hasattr(first_arg, 'data'):
                # El primer argumento es el request (función, no método de clase)
                request = first_arg
            elif second_arg and hasattr(second_arg, 'user') and hasattr(second_arg, 'data'):
                # El segundo argumento es el request
                request = second_arg
        elif len(args) == 1:
            # Solo un argumento - debe ser el request
            if hasattr(args[0], 'user') and hasattr(args[0], 'data'):
                request = args[0]
        
        if request is None:
            return Response(
                {"error": f"No se pudo obtener el request. Args recibidos: {len(args)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        
        user = request.user
        # Si el usuario está autenticado, verificar el rol
        # Si no está autenticado, permitir el acceso de todas formas
        if user.is_authenticated:
            if not user.tiene_rol("Gestor") or not user.suscripcion_activa():
                return Response(
                    {"error": "Funcionalidad exclusiva para gestores con suscripción activa."},
                    status=status.HTTP_403_FORBIDDEN
                )
        return view_func(*args, **kwargs)
    return wrapper


def solo_conductores(view_func):
    @wraps(view_func)
    def wrapper(*args, **kwargs):
        # En métodos de clase de APIView: args[0] = self, args[1] = request
        # Necesitamos extraer el request correctamente
        request = None
        
        # Si hay 2 o más argumentos, y el primero es una instancia de APIView
        # entonces el segundo debe ser el request
        if len(args) >= 2:
            first_arg = args[0]
            second_arg = args[1] if len(args) > 1 else None
            
            # Verificar si el primer argumento es una instancia de APIView
            if isinstance(first_arg, APIView):
                # Es un método de clase, el request es el segundo argumento
                request = second_arg
            elif hasattr(first_arg, 'user') and hasattr(first_arg, 'data'):
                # El primer argumento es el request (función, no método de clase)
                request = first_arg
            elif second_arg and hasattr(second_arg, 'user') and hasattr(second_arg, 'data'):
                # El segundo argumento es el request
                request = second_arg
        elif len(args) == 1:
            # Solo un argumento - debe ser el request
            if hasattr(args[0], 'user') and hasattr(args[0], 'data'):
                request = args[0]
        
        if request is None:
            return Response(
                {"error": f"No se pudo obtener el request. Args recibidos: {len(args)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        
        user = request.user
        # Si el usuario está autenticado, verificar el rol
        # Si no está autenticado, permitir el acceso de todas formas
        if user.is_authenticated and not user.tiene_rol("Conductor"):
            return Response(
                {"error": "Solo los conductores pueden acceder a esta funcionalidad."},
                status=status.HTTP_403_FORBIDDEN
            )
        return view_func(*args, **kwargs)
    return wrapper
