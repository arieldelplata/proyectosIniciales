from django.urls import path
from .views import (
    CalcularRutaView,
    AsignarRutaView,
    ProximidadPuntoRutaView,
    eliminar_direccion,  
)
urlpatterns = [
    path('calcular/', CalcularRutaView.as_view(), name='calcular_ruta'),
    path('asignar/', AsignarRutaView.as_view(), name='asignar_ruta'),
    path("proximidad/", ProximidadPuntoRutaView.as_view(), name="proximidad_punto_ruta"),
    path('<int:id>/', eliminar_direccion, name='eliminar_direccion'),  
]