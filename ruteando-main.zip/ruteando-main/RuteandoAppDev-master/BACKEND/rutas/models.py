from django.db import models
from comun.models import BaseModel
from usuarios.models import Usuario
from geoubicacion.models import APIGeocodingCache
from entregas.models import Entrega, EstadoEntrega


class EstadoRuta(models.TextChoices):
    PENDIENTE = "pendiente", "Pendiente"
    ASIGNADA = "asignada", "Asignada"
    EN_CURSO = "en_curso", "En curso"
    FINALIZADA = "finalizada", "Finalizada"


class Ruta(BaseModel):
    creada_por = models.ForeignKey(Usuario, on_delete=models.SET_NULL, null=True, related_name='rutas_creadas')
    asignada_a = models.ForeignKey(Usuario, on_delete=models.SET_NULL, null=True, related_name='rutas_asignadas')
    fecha_asignacion = models.DateTimeField(null=True, blank=True)
    fecha_inicio = models.DateTimeField(null=True, blank=True)
    fecha_finalizacion = models.DateTimeField(null=True, blank=True)
    estado = models.CharField(max_length=20, choices=EstadoRuta.choices, default=EstadoRuta.PENDIENTE)
    distancia_total_m = models.IntegerField(null=True, blank=True)
    duracion_total_s = models.IntegerField(null=True, blank=True)
    lat_origen = models.DecimalField(max_digits=10, decimal_places=7, null=True, blank=True)
    lng_origen = models.DecimalField(max_digits=10, decimal_places=7, null=True, blank=True)
    solo_lectura = models.BooleanField(default=False)
    geometry = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"Ruta {self.id} - {self.estado}"

class PuntoRuta(BaseModel):
    ruta = models.ForeignKey(Ruta, on_delete=models.CASCADE)
    geocoding_cache = models.ForeignKey(APIGeocodingCache, on_delete=models.SET_NULL, null=True, blank=True)
    orden = models.PositiveIntegerField()
    latitud = models.DecimalField(max_digits=10, decimal_places=7)
    longitud = models.DecimalField(max_digits=10, decimal_places=7)
    fue_visitada = models.BooleanField(default=False)
    hash_geoloc = models.CharField(max_length=128, null=True, blank=True)

    class Meta:
        indexes = [models.Index(fields=['ruta', 'fue_visitada', 'orden'])]

    def __str__(self):
        return f"Punto {self.orden} de Ruta {self.ruta.id}"

class RutaEntrega(BaseModel):
    ruta = models.ForeignKey(Ruta, on_delete=models.CASCADE)
    entrega = models.ForeignKey(Entrega, on_delete=models.CASCADE)
    punto_ruta = models.ForeignKey(PuntoRuta, on_delete=models.CASCADE)
    estado = models.CharField(max_length=20, choices=EstadoEntrega.choices, default=EstadoEntrega.PENDIENTE)
    motivo_falla = models.TextField(null=True, blank=True)
    observacion = models.TextField(null=True, blank=True)
    fecha_asignacion = models.DateTimeField(null=True, blank=True)
    fecha_intento = models.DateTimeField(null=True, blank=True)

    class Meta:
        unique_together = ('ruta', 'entrega', 'punto_ruta')

    def __str__(self):
        return f"Entrega {self.entrega.id} en Ruta {self.ruta.id}"
