from collections import defaultdict
from time import timezone
from django.db import transaction
from django.conf import settings
from rest_framework.views import APIView
from django.http import JsonResponse, HttpResponseNotAllowed
from rest_framework.response import Response
from rest_framework import status
from geoubicacion.models import APIGeocodingCache as Direccion
import requests
from math import radians, sin, cos, sqrt, atan2
from entregas.models import Entrega, EstadoEntrega
from usuarios.decorators import solo_gestores
from usuarios.models import GestorConductor
from rutas.models import EstadoRuta, Ruta, PuntoRuta, RutaEntrega
from geoubicacion.models import APIGeocodingCache
from .serializers import AsignarRutaSerializer, CalcularRutaInputDireccionSerializer, CalcularRutaOutputSerializer

class CalcularRutaView(APIView):
    def post(self, request, *args, **kwargs):
        lat_origen = request.data.get("latitud_origen")
        lng_origen = request.data.get("longitud_origen")
        direcciones_data = request.data.get("direcciones", [])
        reintentos_ids = request.data.get("reintentos", [])

        if not lat_origen or not lng_origen:
            return Response(
                {"error": "Debe incluir latitud_origen y longitud_origen."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # --- Cargar direcciones de entregas a reintentar ---
        direcciones_reintento = []
        if reintentos_ids:
            entregas = Entrega.objects.filter(id__in=reintentos_ids)
            for e in entregas:
                direcciones_reintento.append({
                    "id_entrega": e.id,
                    "texto_normalizado": e.direccion.texto_normalizado,
                    "latitud": e.direccion.geocoding_cache.latitud,
                    "longitud": e.direccion.geocoding_cache.longitud,
                    "hash_geoloc": e.direccion.geocoding_cache.hash_geoloc,
                    "hash_direccion": e.direccion.hash_direccion,
                    "cantidad_paquetes": e.cantidad_paquetes,
                })

        # --- Unificar direcciones nuevas + reintentos ---
        direcciones_totales = direcciones_data + direcciones_reintento
        if not direcciones_totales:
            return Response(
                {"error": "Debe incluir al menos una dirección o entrega a reintentar."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # --- Agrupar por hash_geoloc (evita duplicados en el mismo lugar físico) ---
        grupos = defaultdict(list)
        for d in direcciones_totales:
            grupos[d["hash_geoloc"]].append(d)


        puntos_unicos = []
        for hash_geo, lista in grupos.items():
            puntos_unicos.append({
                "hash_geoloc": hash_geo,
                "lat": float(lista[0]["latitud"]),
                "lng": float(lista[0]["longitud"]),
                "direcciones_fisicas": lista,
            })

        if not puntos_unicos:
            return Response(
                {"error": "No se encontraron coordenadas válidas."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # --- Preparar request para Google Directions API ---
        directions_url = "https://maps.googleapis.com/maps/api/directions/json"
        api_key = settings.GOOGLE_MAPS_API_KEY

        # No fijamos destino: probamos cada dirección como destino y elegimos la ruta más corta
        best_total_m = None
        best_destination = None
        best_intermedios = None
        best_order = None

        for idx_dest, candidate_destination in enumerate(puntos_unicos):
            intermedios = [p for j, p in enumerate(puntos_unicos) if j != idx_dest]
            waypoints_str = "|".join(f"{p['lat']},{p['lng']}" for p in intermedios)

            params = {
                "origin": f"{lat_origen},{lng_origen}",
                "destination": f"{candidate_destination['lat']},{candidate_destination['lng']}",
                "waypoints": f"optimize:true|{waypoints_str}" if waypoints_str else "",
                "key": api_key,
            }

            try:
                directions_resp = requests.get(directions_url, params=params)
                directions_resp.raise_for_status()
                directions_data = directions_resp.json()
            except Exception as e:
                return Response(
                    {"error": f"Error al consultar Google Directions API: {str(e)}"},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR,
                )

            if directions_data.get("status") != "OK":
                return Response(
                    {"error": f"Error en respuesta de Google: {directions_data.get('status')}"},
                    status=status.HTTP_500_INTERNAL_SERVER_ERROR,
                )

            route_dirs = directions_data["routes"][0]
            optimized_order = route_dirs.get("waypoint_order", [])
            legs = route_dirs.get("legs", [])
            total_m = 0
            for leg in legs:
                dist = leg.get("distance", {}).get("value")
                if isinstance(dist, (int, float)):
                    total_m += dist

            if best_total_m is None or total_m < best_total_m:
                best_total_m = total_m
                best_destination = candidate_destination
                best_intermedios = intermedios
                best_order = optimized_order

        # --- Construir el orden final con la mejor combinación ---
        punto_origen = {
            "hash_geoloc": None,
            "lat": float(lat_origen),
            "lng": float(lng_origen),
            "direcciones_fisicas": [],
        }

        # Asegurarnos de que best_intermedios y best_destination estén definidos
        if best_destination is None:
            # Si no se encontró mejor destino, usar el último punto único como destino
            if puntos_unicos:
                best_destination = puntos_unicos[-1]
                best_intermedios = puntos_unicos[:-1]
                best_order = list(range(len(best_intermedios))) if best_intermedios else []
            else:
                return Response(
                    {"error": "No se pudo determinar el destino de la ruta."},
                    status=status.HTTP_400_BAD_REQUEST,
                )

        # Asegurar que best_intermedios sea una lista (no None)
        if best_intermedios is None:
            best_intermedios = []

        # Construir puntos_ordenados: origen + intermedios ordenados + destino
        puntos_ordenados = [punto_origen]
        
        # Agregar intermedios en el orden optimizado (si hay)
        if best_intermedios:
            if best_order and len(best_order) == len(best_intermedios):
                # Usar el orden optimizado de Google
                intermedios_ordenados = [best_intermedios[i] for i in best_order]
                puntos_ordenados.extend(intermedios_ordenados)
            else:
                # Si no hay orden optimizado válido, usar el orden original
                puntos_ordenados.extend(best_intermedios)
        
        # Agregar el destino al final (verificar que no esté duplicado)
        # El destino NO debería estar en best_intermedios por la lógica del bucle,
        # pero verificamos por seguridad usando coordenadas
        if best_destination:
            # Verificar si el destino ya está en puntos_ordenados (por coordenadas)
            destino_lat = float(best_destination.get("lat", 0))
            destino_lng = float(best_destination.get("lng", 0))
            destino_duplicado = False
            
            for p in puntos_ordenados:
                p_lat = float(p.get("lat", 0))
                p_lng = float(p.get("lng", 0))
                # Comparar coordenadas con tolerancia de 0.0001 grados (~11 metros)
                if abs(p_lat - destino_lat) < 0.0001 and abs(p_lng - destino_lng) < 0.0001:
                    destino_duplicado = True
                    print(f"⚠️ Advertencia: El destino ya está en puntos_ordenados (lat: {destino_lat}, lng: {destino_lng})")
                    break
            
            if not destino_duplicado:
                puntos_ordenados.append(best_destination)
        
        # Validación final: verificar que el número de puntos sea el esperado
        puntos_esperados = 1 + len(best_intermedios) + (1 if best_destination else 0)
        if len(puntos_ordenados) != puntos_esperados:
            print(f"⚠️ ADVERTENCIA: Número de puntos inconsistente!")
            print(f"   Esperado: {puntos_esperados} puntos (1 origen + {len(best_intermedios)} intermedios + 1 destino)")
            print(f"   Obtenido: {len(puntos_ordenados)} puntos")
            print(f"   puntos_unicos: {len(puntos_unicos)}")
            print(f"   best_intermedios: {len(best_intermedios)}")
            print(f"   best_order: {best_order}")
        
        # Debug: información sobre la construcción
        print(f"🔍 Debug: puntos_unicos={len(puntos_unicos)}, best_intermedios={len(best_intermedios)}, best_order={best_order}, puntos_ordenados={len(puntos_ordenados)}")
        print(f"🔍 Esperado: 1 (origen) + {len(best_intermedios)} (intermedios) + 1 (destino) = {puntos_esperados} puntos")

        print("🔢 Orden final (sin destino fijo, vía Google):")
        for i, p in enumerate(puntos_ordenados):
            print(f"{i}: {p['lat']}, {p['lng']} (hash: {p.get('hash_geoloc')})")

        # --- Eliminar duplicados de puntos_ordenados (por seguridad) ---
        # Mantenemos el primer punto (origen) y eliminamos duplicados posteriores
        puntos_sin_duplicados = [puntos_ordenados[0]]  # Siempre incluir el origen
        puntos_vistos = set()
        
        # Para el origen, usar coordenadas como identificador
        origen_key = (round(float(puntos_ordenados[0]["lat"]), 6), round(float(puntos_ordenados[0]["lng"]), 6))
        puntos_vistos.add(origen_key)
        
        # Procesar el resto de los puntos (intermedios + destino)
        for punto in puntos_ordenados[1:]:
            punto_lat = round(float(punto["lat"]), 6)
            punto_lng = round(float(punto["lng"]), 6)
            punto_key = (punto_lat, punto_lng)
            
            if punto_key not in puntos_vistos:
                puntos_sin_duplicados.append(punto)
                puntos_vistos.add(punto_key)
            else:
                print(f"⚠️ Punto duplicado eliminado: ({punto_lat}, {punto_lng})")
        
        # Actualizar puntos_ordenados con la lista sin duplicados
        if len(puntos_sin_duplicados) != len(puntos_ordenados):
            print(f"🔧 Duplicados eliminados: {len(puntos_ordenados)} -> {len(puntos_sin_duplicados)} puntos")
            puntos_ordenados = puntos_sin_duplicados

        # --- Calcular ruta final con Routes API (para obtener polyline, distancia, duración) ---
        url_routes = "https://routes.googleapis.com/directions/v2:computeRoutes"
        headers = {
            "Content-Type": "application/json",
            "X-Goog-Api-Key": api_key,
            "X-Goog-FieldMask": (
                "routes.distanceMeters,routes.duration,"
                "routes.polyline.encodedPolyline,routes.legs"
            ),
        }

        request_body = {
            "origin": {
                "location": {
                    "latLng": {
                        "latitude": float(lat_origen),
                        "longitude": float(lng_origen),
                    }
                }
            },
            "destination": {
                "location": {
                    "latLng": {
                        "latitude": puntos_ordenados[-1]["lat"],
                        "longitude": puntos_ordenados[-1]["lng"],
                    }
                }
            },
            "intermediates": [
                {"location": {"latLng": {"latitude": p["lat"], "longitude": p["lng"]}}}
                for p in puntos_ordenados[1:-1]
            ],
            "travelMode": "DRIVE",
            "routingPreference": "TRAFFIC_AWARE",
            "polylineQuality": "OVERVIEW",
            "computeAlternativeRoutes": False,
        }

        try:
            routes_resp = requests.post(url_routes, json=request_body, headers=headers)
            routes_resp.raise_for_status()
            route_data = routes_resp.json()
        except Exception as e:
            return Response(
                {"error": f"Error al consultar Google Routes API: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        routes = route_data.get("routes", [])
        if not routes:
            return Response(
                {"error": "La API de Google no devolvió rutas válidas."},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )

        route = routes[0]
        total_distance = int(float(route.get("distanceMeters", 0)))
        raw_duration = route.get("duration", "0s")
        total_duration = int(float(raw_duration.replace("s", ""))) if "s" in raw_duration else 0
        encoded_polyline = route.get("polyline", {}).get("encodedPolyline", "")

        # --- Guardar ruta y puntos en la base ---
        with transaction.atomic():
            ruta = Ruta.objects.create(
                distancia_total_m=total_distance,
                duracion_total_s=total_duration,
                geometry=encoded_polyline,
                estado=EstadoRuta.PENDIENTE,
            )

            puntos_ruta_response = []
            # Filtrar puntos que no tienen hash_geoloc (como el origen) - solo crear PuntoRuta para direcciones reales
            puntos_para_guardar = [p for p in puntos_ordenados if p.get("hash_geoloc") is not None]
            
            for idx, punto in enumerate(puntos_para_guardar, start=1):
                geocache = APIGeocodingCache.objects.filter(hash_geoloc=punto["hash_geoloc"]).first()

                punto_ruta = PuntoRuta.objects.create(
                    ruta=ruta,
                    geocoding_cache=geocache,
                    orden=idx,
                    latitud=punto["lat"],
                    longitud=punto["lng"],
                    fue_visitada=False,
                    hash_geoloc=getattr(geocache, "hash_geoloc", None),
                )

                puntos_ruta_response.append({
                    "punto_ruta_id": punto_ruta.id,
                    "orden": idx,
                    "hash_geoloc": punto["hash_geoloc"],
                    "direcciones_fisicas": punto["direcciones_fisicas"],
                })

        # --- Respuesta final ---
        return Response({
            "ruta_id": ruta.id,
            "distancia_total_m": total_distance,
            "duracion_total_s": total_duration,
            "encoded_polyline": encoded_polyline,
            "puntos_ruta": puntos_ruta_response,
        }, status=status.HTTP_200_OK)

class AsignarRutaView(APIView):
    # Permite al Gestor asignar una ruta a un Conductor vinculado.
    # Valida que:
    #   - El usuario autenticado tenga rol Gestor y suscripción activa.
    #   - El conductor esté vinculado al gestor (GestorConductor.es_active=True).
    #   - La ruta no esté ya asignada.

    @solo_gestores
    def post(self, request):
        user = request.user  # Gestor autenticado
        serializer = AsignarRutaSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        ruta = serializer.validated_data["ruta"]
        conductor = serializer.validated_data["conductor"]

        # Validar vínculo Gestor–Conductor
        if not GestorConductor.objects.filter(
            gestor=user, conductor=conductor, es_active=True
        ).exists():
            return Response(
                {"error": "No puedes asignar rutas a un conductor no vinculado."},
                status=status.HTTP_403_FORBIDDEN
            )

        # Verificar si la ruta ya está asignada
        if ruta.asignada_a:
            if ruta.asignada_a == conductor:
                return Response(
                    {"detalle": "La ruta ya está asignada a este conductor."},
                    status=status.HTTP_200_OK
                )
            return Response(
                {"error": "La ruta ya está asignada a otro conductor."},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Asignar ruta
        ruta.asignada_a = conductor
        ruta.estado = EstadoRuta.ASIGNADA
        ruta.fecha_asignacion = timezone.now()
        ruta.solo_lectura = True
        ruta.creada_por = user  # Para registrar quién la asignó
        ruta.save()

        return Response({
            "mensaje": f"Ruta {ruta.id} asignada correctamente a {conductor.username}.",
            "ruta_id": ruta.id,
            "conductor_id": conductor.id,
            "asignada_por": user.username,
            "fecha_asignacion": ruta.fecha_asignacion
        }, status=status.HTTP_200_OK)


##########################################################################################
# Verificar Proximidad al Punto de Ruta
# Calcular distancia entre dos puntos GPS usando la fórmula Haversine
# def distancia_metros(lat1, lon1, lat2, lon2):
#     R = 6371000
#     dlat = radians(lat2 - lat1)
#     dlon = radians(lon2 - lon1)
#     a = sin(dlat / 2)**2 + cos(radians(lat1)) * cos(radians(lat2)) * sin(dlon / 2)**2
#     c = 2 * atan2(sqrt(a), sqrt(1 - a))
#     return R * c

PROXIMIDAD_METROS = getattr(settings, "ENTREGA_PROXIMIDAD_METROS", 50)
class ProximidadPuntoRutaView(APIView):
    # Detecta si el conductor está próximo (<50m) al siguiente punto de entrega.
    # Si está cerca, devuelve las entregas asociadas a ese punto para permitir su registro.
    # Si no, no devuelve contenido (204).

    def post(self, request):
        ruta_id = request.data.get("ruta_id")
        lat_actual = request.data.get("latitud_actual")
        lng_actual = request.data.get("longitud_actual")

        if not all([ruta_id, lat_actual, lng_actual]):
            return Response(
                {"error": "Debe enviar ruta_id, latitud_actual y longitud_actual."},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            ruta = Ruta.objects.get(id=ruta_id)
        except Ruta.DoesNotExist:
            return Response({"error": "Ruta no encontrada."}, status=status.HTTP_404_NOT_FOUND)

        if ruta.estado != EstadoRuta.EN_CURSO:
            return Response(
                {"error": "Solo puede verificar proximidad en rutas en curso."},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Obtener el siguiente punto no visitado
        punto_actual = ruta.puntoruta_set.filter(fue_visitada=False).order_by("orden").first()
        if not punto_actual:
            return Response({"mensaje": "Ruta completada."}, status=status.HTTP_200_OK)

        # Calcular distancia (Haversine)
        def distancia_metros(lat1, lon1, lat2, lon2):
            R = 6371000
            dlat = radians(lat2 - lat1)
            dlon = radians(lon2 - lon1)
            a = sin(dlat / 2) ** 2 + cos(radians(lat1)) * cos(radians(lat2)) * sin(dlon / 2) ** 2
            c = 2 * atan2(sqrt(a), sqrt(1 - a))
            return R * c

        distancia = distancia_metros(
            float(lat_actual), float(lng_actual),
            float(punto_actual.latitud), float(punto_actual.longitud)
        )

        # Si no está cerca todavía
        if distancia > PROXIMIDAD_METROS:
            return Response(status=status.HTTP_204_NO_CONTENT)

        # Si llegó al punto: devolver entregas asociadas
        ruta_entregas = RutaEntrega.objects.filter(
            punto_ruta=punto_actual,
            estado=EstadoEntrega.PENDIENTE
        ).select_related("entrega", "entrega__direccion")

        entregas_serializadas = [
            {
                "entrega_id": re.entrega.id,
                "ruta_entrega_id": re.id,
                "direccion": re.entrega.direccion.texto_normalizado,
                "cantidad_paquetes": re.entrega.cantidad_paquetes,
                "estado": re.entrega.estado_global,
                "piso": re.entrega.direccion.piso,
                "depto": re.entrega.direccion.depto,
            }
            for re in ruta_entregas
        ]

        # Marcar el punto como visitado (solo si todas las entregas ya fueron finalizadas)
        if not entregas_serializadas:  # o si se completan luego
            punto_actual.fue_visitada = True
            punto_actual.save()

        return Response({
            "punto_ruta_id": punto_actual.id,
            "orden": punto_actual.orden,
            "distancia_m": round(distancia, 2),
            "entregas_asociadas": entregas_serializadas
        }, status=status.HTTP_200_OK)
        
def eliminar_direccion(request, id):
    """
    Elimina una dirección por ID.
    """
    if request.method != 'DELETE':
        return HttpResponseNotAllowed(['DELETE'])

    try:
        direccion = Direccion.objects.get(id=id)
        direccion.delete()
        return JsonResponse({'mensaje': 'Dirección eliminada correctamente'})
    except Direccion.DoesNotExist:
        return JsonResponse({'error': 'Dirección no encontrada'}, status=404)