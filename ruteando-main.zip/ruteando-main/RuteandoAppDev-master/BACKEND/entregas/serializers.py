from rest_framework import serializers 
from entregas.models import Entrega
from rutas.models import Ruta
from usuarios.models import Usuario


class IniciarRutaSerializer(serializers.Serializer):
    ruta_id = serializers.IntegerField()
    conductor_id = serializers.IntegerField(required=False, allow_null=True)  # 🟢 MODIFICADO: ahora opcional

    def validate(self, data):
        # --- Validar ruta ---
        try:
            data["ruta"] = Ruta.objects.get(id=data["ruta_id"])
        except Ruta.DoesNotExist:
            raise serializers.ValidationError("La ruta no existe.")

        ruta = data["ruta"]

        # --- Obtener conductor ---
        conductor_id = data.get("conductor_id")  # 🟢 AGREGADO
        conductor = None  # 🟢 AGREGADO

        if conductor_id:  # 🟢 AGREGADO
            conductor = Usuario.objects.filter(id=conductor_id).first()

        # 🟢 AGREGADO: fallback automático sin autenticación
        if not conductor:
            conductor = Usuario.objects.filter(rol_actual="Conductor").first()
            if not conductor:
                conductor = Usuario.objects.create(
                    username="conductor_demo",
                    rol_actual="Conductor",
                    is_active=True,
                )

        data["conductor"] = conductor  # 🟢 AGREGADO

        # --- Caso 1: ruta creada o sin asignar, se autoasigna ---
        # 🟢 AGREGADO: permite iniciar aunque no haya autenticación
        if not ruta.asignada_a or ruta.creada_por == conductor:
            ruta.asignada_a = conductor
            ruta.solo_lectura = False
            ruta.estado = "pendiente"
            ruta.save()
            return data

        # --- Caso 2: ruta asignada a otro conductor ---
        # 🔁 MODIFICADO: antes lanzaba error fijo; ahora permite autoasignar si demo
        if ruta.asignada_a and ruta.asignada_a != conductor:
            # si la ruta estaba asignada a alguien inexistente o dummy, reasignamos
            if ruta.asignada_a.username == "conductor_demo":
                ruta.asignada_a = conductor
                ruta.estado = "pendiente"
                ruta.save()
            else:
                raise serializers.ValidationError("Esta ruta no está asignada a este conductor.")

        # --- Validar estado de la ruta ---
        if ruta.estado not in ["asignada", "pendiente"]:
            raise serializers.ValidationError("Solo pueden iniciarse rutas pendientes o asignadas.")

        return data



class EntregaSerializer(serializers.ModelSerializer):
    direccion_texto = serializers.SerializerMethodField()

    class Meta:
        model = Entrega
        fields = [
            "id",
            "estado_global",
            "observacion",
            "cantidad_paquetes",
            "direccion_texto",
            "created_at",
            "updated_at",
        ]

    def get_direccion_texto(self, obj):
        if obj.direccion:
            base = f"{obj.direccion.calle} {obj.direccion.numero}, {obj.direccion.ciudad}"
            if obj.direccion.piso or obj.direccion.depto:
                base += f", Piso {obj.direccion.piso or ''} Dpto {obj.direccion.depto or ''}"
            return base
        return None
