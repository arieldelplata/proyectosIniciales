from datetime import datetime
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.db import transaction
from django.utils import timezone
from usuarios.decorators import solo_conductores
from usuarios.models import GestorConductor, Usuario
from rutas.models import EstadoRuta, Ruta, RutaEntrega, PuntoRuta
from entregas.models import Entrega, EstadoEntrega, IntentoEntrega
from geoubicacion.models import Direccion
from .serializers import EntregaSerializer, IniciarRutaSerializer

# ------------------------------------------------------------------------
# Iniciar Ruta: Formato correcto y uniforme para las respuestas y los datos
class IniciarRutaView(APIView):
    """
    Permite a un conductor iniciar una ruta asignada o creada por él.
    - Cambia el estado de la ruta a 'en_curso'.
    - Crea entregas si no existen (pendientes o fallidas).
    - Crea las relaciones RutaEntrega.
    """
    #@solo_conductores
    def post(self, request):
        serializer = IniciarRutaSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        ruta = serializer.validated_data["ruta"]
        conductor = serializer.validated_data["conductor"]

        if ruta.asignada_a != conductor and ruta.creada_por != conductor:
            return Response(
                {"error": "No tienes permiso para iniciar esta ruta."},
                status=status.HTTP_403_FORBIDDEN,
            )

        if ruta.estado not in [EstadoRuta.PENDIENTE, EstadoRuta.ASIGNADA]:
            return Response(
                {"error": f"No se puede iniciar una ruta en estado '{ruta.estado}'."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        with transaction.atomic():
            for punto in ruta.puntoruta_set.all():
                print(f"[DEBUG] Buscando direcciones para punto {punto.id} ({punto.latitud}, {punto.longitud})")

                # 🔍 Si el punto tiene hash, buscamos por hash. Sino, usamos coordenadas.
                if getattr(punto, "hash_geoloc", None):
                    # 🔧 Buscar solo las direcciones exactas (no todos los deptos del edificio)
                    direcciones = Direccion.objects.filter(
                        geocoding_cache__hash_geoloc=punto.hash_geoloc
                    ).order_by("piso", "depto")
                    print(f"[DEBUG] Buscando por hash {punto.hash_geoloc}")
                else:
                    try:
                        lat = float(punto.latitud)
                        lon = float(punto.longitud)
                        direcciones = Direccion.objects.filter(
                            geocoding_cache__latitud__range=(lat - 0.00005, lat + 0.00005),
                            geocoding_cache__longitud__range=(lon - 0.00005, lon + 0.00005),
                        )
                        print(f"[DEBUG] Buscando por coordenadas ({lat}, {lon})")
                    except Exception as e:
                        print(f"[ERROR] Coordenadas inválidas en punto {punto.id}: {e}")
                        continue

                print(f"[DEBUG] ✅ Direcciones encontradas: {direcciones.count()}")

                # Crear o reutilizar entregas
                for direccion in direcciones:
                    # Verificamos si ya existe una entrega para esta dirección EXACTA
                    entrega_existente = Entrega.objects.filter(
                        conductor=conductor,
                        direccion=direccion,
                        estado_global__in=[EstadoEntrega.PENDIENTE, EstadoEntrega.FALLIDA]
                    ).first()

                    # ⚠️ Si la dirección tiene mismo hash_geoloc pero distinto piso/depto,
                    # no debemos reutilizar la entrega.
                    if (
                        entrega_existente
                        and (
                            entrega_existente.direccion.piso != direccion.piso
                            or entrega_existente.direccion.depto != direccion.depto
                        )
                    ):
                        entrega_existente = None

                    if entrega_existente:
                        entrega = entrega_existente
                    else:
                        entrega = Entrega.objects.create(
                            conductor=conductor,
                            direccion=direccion,
                            estado_global=EstadoEntrega.PENDIENTE,
                            cantidad_paquetes=getattr(direccion, "cantidad_paquetes", 1),
                            es_modificable=False,
                        )

                    RutaEntrega.objects.update_or_create(
                        ruta=ruta,
                        entrega=entrega,
                        punto_ruta=punto,
                        defaults={
                            "estado": EstadoEntrega.PENDIENTE,
                            "fecha_asignacion": timezone.now(),
                        }
                    )

            # Marcar la ruta como iniciada
            ruta.estado = EstadoRuta.EN_CURSO
            ruta.fecha_inicio = timezone.now()
            ruta.save()

        entregas_data = []
        for relacion in RutaEntrega.objects.filter(ruta=ruta).select_related("entrega__direccion", "punto_ruta"):
            direccion = relacion.entrega.direccion
            punto_ruta = relacion.punto_ruta
            hash_geo = getattr(direccion, "geocoding_cache", None)

            # ✅ Usamos coordenadas reales del punto (no del hash)
            latitud = float(punto_ruta.latitud) if punto_ruta and punto_ruta.latitud else None
            longitud = float(punto_ruta.longitud) if punto_ruta and punto_ruta.longitud else None

            entregas_data.append({
                "ruta_entrega_id": relacion.id,
                "entrega_id": relacion.entrega.id,
                "direccion_id": direccion.id,
                "estado": relacion.estado,
                "latitud": latitud,
                "longitud": longitud,
                "texto_normalizado": getattr(direccion, "texto_normalizado", ""),
                "hash_geoloc": getattr(hash_geo, "hash_geoloc", None) or getattr(direccion, "hash_geoloc", None),
            })
            print(f"[DEBUG] hash_enviado: {getattr(hash_geo, 'hash_geoloc', None)}")

        # --- Respuesta final ---
        print("[DEBUG BACKEND] Entregas creadas enviadas al frontend:")
        for e in entregas_data:
            print(f"  - ruta_entrega_id={e.get('ruta_entrega_id')}  direccion={e.get('texto_normalizado')}  hash={e.get('hash_geoloc')}")

        return Response({
            "mensaje": "Ruta iniciada correctamente.",
            "ruta_id": ruta.id,
            "polyline": ruta.geometry,
            "distancia_total_m": ruta.distancia_total_m,
            "duracion_total_s": ruta.duracion_total_s,
            "conductor": conductor.username,
            "estado": ruta.estado,
            "entregas_creadas": entregas_data,
        }, status=status.HTTP_200_OK)

# ------------------------------------------------------------------------
# Registrar intento de entrega, formato consistente en respuestas
class RegistrarIntentoEntregaView(APIView):
    """
    Registra un intento de entrega (Fallida o Finalizada).
    Actualiza el estado global de la Entrega y el estado de RutaEntrega.
    """
    #@solo_conductores
    def post(self, request, *args, **kwargs):
        data = request.data
        ruta_entrega_id = data.get("ruta_entrega_id")
        conductor_id = data.get("conductor_id")
        nuevo_estado = data.get("nuevo_estado")
        motivo = data.get("motivo")
        ubicacion_gps = data.get("ubicacion_gps")
        adjuntos_json = data.get("adjuntos_json", {})

        print(f"[DEBUG RegistrarIntentoEntrega] ruta_entrega_id={ruta_entrega_id}, conductor_id={conductor_id}, nuevo_estado={nuevo_estado}")

        if not all([ruta_entrega_id, conductor_id, nuevo_estado]):
            return Response(
                {"error": "Faltan campos obligatorios (ruta_entrega_id, conductor_id, nuevo_estado)."},
                status=status.HTTP_400_BAD_REQUEST
            )

        if nuevo_estado not in [EstadoEntrega.COMPLETADA, EstadoEntrega.FALLIDA]:
            return Response(
                {"error": "El estado de entrega debe ser 'completada' o 'fallida'."},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            ruta_entrega = RutaEntrega.objects.select_related(
                "entrega", "ruta", "punto_ruta"
            ).get(id=ruta_entrega_id)
        except RutaEntrega.DoesNotExist:
            return Response({"error": "RutaEntrega no encontrada."}, status=status.HTTP_404_NOT_FOUND)

        entrega = ruta_entrega.entrega

        try:
            conductor = Usuario.objects.get(id=conductor_id)
        except Usuario.DoesNotExist:
            return Response({"error": "Conductor no encontrado."}, status=status.HTTP_404_NOT_FOUND)

        if entrega.conductor_id != conductor.id:
            return Response(
                {"error": "El conductor no está autorizado para modificar esta entrega."},
                status=status.HTTP_403_FORBIDDEN
            )

        if ruta_entrega.ruta.estado != EstadoRuta.EN_CURSO:
            return Response(
                {"error": "Solo se pueden registrar intentos en rutas en curso."},
                status=status.HTTP_400_BAD_REQUEST
            )

        if entrega.estado_global == EstadoEntrega.COMPLETADA:
            return Response(
                {"error": "La entrega ya fue completada y no puede modificarse."},
                status=status.HTTP_400_BAD_REQUEST
            )

        ahora = timezone.now()

        print(f"[DEBUG RegistrarIntentoEntrega] entrega={entrega.id}, direccion={entrega.direccion.id}, direccion.piso={entrega.direccion.piso}, direccion.depto={entrega.direccion.depto}")

        with transaction.atomic():
            intento = IntentoEntrega.objects.create(
                entrega=entrega,
                conductor=conductor,
                ruta_entrega=ruta_entrega,
                estado_anterior=entrega.estado_global,
                nuevo_estado=nuevo_estado,
                motivo=motivo,
                ubicacion_gps=ubicacion_gps,
                adjuntos_json=adjuntos_json
            )

            entrega.estado_global = nuevo_estado
            entrega.ultimo_estado_en = ahora
            if nuevo_estado == EstadoEntrega.COMPLETADA:
                entrega.fecha_cierre = ahora
            entrega.save()

            ruta_entrega.estado = nuevo_estado
            ruta_entrega.fecha_intento = ahora
            if nuevo_estado == EstadoEntrega.FALLIDA and motivo:
                ruta_entrega.motivo_falla = motivo
            ruta_entrega.save()

            pendientes_en_punto = RutaEntrega.objects.filter(
                punto_ruta=ruta_entrega.punto_ruta,
                estado=EstadoEntrega.PENDIENTE
            ).exists()

            if not pendientes_en_punto:
                ruta_entrega.punto_ruta.fue_visitada = True
                ruta_entrega.punto_ruta.save()

            quedan_pendientes_en_ruta = RutaEntrega.objects.filter(
                ruta=ruta_entrega.ruta,
                estado=EstadoEntrega.PENDIENTE
            ).exists()

            if not quedan_pendientes_en_ruta:
                ruta = ruta_entrega.ruta
                ruta.estado = EstadoRuta.FINALIZADA
                ruta.fecha_finalizacion = ahora
                ruta.save()

        return Response({
            "mensaje": "Intento registrado correctamente.",
            "entrega_id": entrega.id,
            "nuevo_estado": nuevo_estado,
            "ruta_entrega_id": ruta_entrega.id,
            "estado_ruta": ruta_entrega.ruta.estado,
            "fecha_intento": intento.created_at,
        }, status=status.HTTP_200_OK)

# ------------------------------------------------------------------------
# Historial de Entregas: formato homogéneo de salida
class HistorialEntregasView(APIView):
    """
    Devuelve el historial de entregas, filtrable por fecha y estado.
    - Conductor: ve solo sus entregas.
    - Gestor: ve las entregas de los conductores que él gestiona,
      pero solo de rutas que él mismo creó.
    """
    def get(self, request, *args, **kwargs):
        user = request.user
        conductor_id = request.query_params.get("conductor_id")
        estado = request.query_params.get("estado")
        fecha_inicio = request.query_params.get("fecha_inicio")
        fecha_fin = request.query_params.get("fecha_fin")

        try:
            if fecha_inicio:
                fecha_inicio = datetime.strptime(fecha_inicio, "%Y-%m-%d").date()
            if fecha_fin:
                fecha_fin = datetime.strptime(fecha_fin, "%Y-%m-%d").date()
        except ValueError:
            return Response(
                {"error": "Formato de fecha inválido. Use YYYY-MM-DD."},
                status=status.HTTP_400_BAD_REQUEST
            )

        if user.tiene_rol("Conductor"):
            entregas = Entrega.objects.filter(conductor=user)
            rol_str = "conductor"
        elif user.tiene_rol("Gestor"):
            if not conductor_id:
                return Response(
                    {"error": "Debe indicar conductor_id para ver su historial."},
                    status=status.HTTP_400_BAD_REQUEST
                )

            vinculo_activo = GestorConductor.objects.filter(
                gestor=user, conductor_id=conductor_id, activo=True
            ).exists()
            if not vinculo_activo:
                return Response(
                    {"error": "El conductor no está vinculado a este gestor."},
                    status=status.HTTP_403_FORBIDDEN
                )

            entregas = Entrega.objects.filter(
                conductor_id=conductor_id,
                rutaentrega__ruta__creada_por=user
            ).distinct()
            rol_str = "gestor"
        else:
            return Response(
                {"error": "Rol no autorizado para acceder al historial de entregas."},
                status=status.HTTP_403_FORBIDDEN
            )

        if estado:
            valores_validos = {e for e, _ in EstadoEntrega.choices}
            if estado not in valores_validos:
                return Response({"error": "Estado inválido."}, status=status.HTTP_400_BAD_REQUEST)
            entregas = entregas.filter(estado_global=estado)

        if fecha_inicio:
            entregas = entregas.filter(created_at__date__gte=fecha_inicio)
        if fecha_fin:
            entregas = entregas.filter(created_at__date__lte=fecha_fin)

        entregas = entregas.select_related("direccion")
        serializer = EntregaSerializer(entregas, many=True)

        return Response({
            "rol": rol_str,
            "cantidad_entregas": entregas.count(),
            "filtros": {
                "estado": estado,
                "fecha_inicio": str(fecha_inicio) if fecha_inicio else None,
                "fecha_fin": str(fecha_fin) if fecha_fin else None,
                "conductor_id": conductor_id,
            },
            "entregas": serializer.data
        }, status=status.HTTP_200_OK)

# ------------------------------------------------------------------------
# Finalizar Ruta: formato estándar de respuesta y manejo de registros
class FinalizarRutaView(APIView):
    """
    Permite al conductor finalizar una ruta en curso.
    - Cambia el estado de la ruta a 'finalizada'.
    - Marca las entregas pendientes como fallidas.
    - Actualiza estados en RutaEntrega.
    - Registra intentos automáticos de entrega fallida para trazabilidad.
    """
    #@solo_conductores
    def post(self, request):
        ruta_id = request.data.get("ruta_id")
        conductor_id = request.data.get("conductor_id")

        if not ruta_id or not conductor_id:
            return Response(
                {"error": "Faltan datos requeridos (ruta_id, conductor_id)."},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            ruta = Ruta.objects.select_related("asignada_a").get(
                id=ruta_id, asignada_a_id=conductor_id, estado=EstadoRuta.EN_CURSO
            )
        except Ruta.DoesNotExist:
            return Response(
                {"error": "Ruta no encontrada o no está en curso."},
                status=status.HTTP_404_NOT_FOUND
            )

        ahora = timezone.now()

        with transaction.atomic():
            entregas_pendientes = Entrega.objects.filter(
                rutaentrega__ruta=ruta,
                estado_global=EstadoEntrega.PENDIENTE
            ).distinct()

            cantidad_fallidas = entregas_pendientes.count()

            for entrega in entregas_pendientes:
                entrega.estado_global = EstadoEntrega.FALLIDA
                entrega.ultimo_estado_en = ahora
                entrega.fecha_cierre = ahora
                entrega.save()

                ruta_entrega = RutaEntrega.objects.filter(
                    ruta=ruta, entrega=entrega
                ).first()

                if ruta_entrega:
                    ruta_entrega.estado = EstadoEntrega.FALLIDA
                    ruta_entrega.fecha_intento = ahora
                    ruta_entrega.motivo_falla = "Entrega no completada al cierre de la ruta."
                    ruta_entrega.save()

                    IntentoEntrega.objects.create(
                        entrega=entrega,
                        ruta_entrega=ruta_entrega,
                        conductor=ruta.asignada_a,
                        estado_anterior=EstadoEntrega.PENDIENTE,
                        nuevo_estado=EstadoEntrega.FALLIDA,
                        motivo="Ruta finalizada sin completar la entrega.",
                        ubicacion_gps=None,
                        adjuntos_json={}
                    )

                    pendientes_en_punto = RutaEntrega.objects.filter(
                        punto_ruta=ruta_entrega.punto_ruta,
                        estado=EstadoEntrega.PENDIENTE
                    ).exists()

                    if not pendientes_en_punto:
                        ruta_entrega.punto_ruta.fue_visitada = True
                        ruta_entrega.punto_ruta.save()

            ruta.estado = EstadoRuta.FINALIZADA
            ruta.fecha_finalizacion = ahora
            ruta.save()

        return Response({
            "mensaje": f"Ruta finalizada correctamente. {cantidad_fallidas} entregas marcadas como fallidas.",
            "ruta_id": ruta.id,
            "estado_final": ruta.estado,
            "fecha_finalizacion": ruta.fecha_finalizacion,
        }, status=status.HTTP_200_OK)